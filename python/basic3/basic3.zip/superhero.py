""" superhero.py
    demonstrates using a for() structure
    to step through a list
    3/22/06 """

heroes = [
    "Buffalo Man",
    "Geek Boy",
    "Wiffle-Ball Woman"
    ]

for hero in heroes:
    print("Never fear, {}is here.".format(hero))



