"""Cheese Shop
    cheeseShop.py
    demonstrate comments
    raw input,
    and string variables    from Game Programming - L-line
    Andy Harris
    4/10/06

    modded for Python 3 2014
    """

#tell the user something
print("Welcome to the cheese shop!")

#get information from the user
cheeseType = input("What kind of cheese would you like? ")

#we don't have that kind...
print "Sorry, We're all out of "
print cheeseType



