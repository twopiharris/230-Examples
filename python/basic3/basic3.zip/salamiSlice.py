""" salamiSlice.py
    salami slicer
    demonstrates string slicing
    3/20/06 """

print("GUIDE:")
print("0 1 2 3 4 5 6")
print("|s|a|l|a|m|i|")
print()

meat = "salami"

print("meat[2:5]", meat[2:5])
print("meat[:3]", meat[:3])
print("meat[2:]", meat[2:])
print("meat[-3:]", meat[-3:])
print("meat[1]", meat[1])





