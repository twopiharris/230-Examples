#!/usr/bin/python

""" qAndA.py

    asks a question and returns the
    response
"""
import cgi
header =  "Content-type: text/html \n\n"
form = cgi.FieldStorage()

def createForm():
    print header
    print """
<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang = "EN" xml:lang = "EN" dir = "ltr">

<head>
<meta http-equiv="content-type" content="text/xml; charset=iso-8859-1" />

<title>Please tell me your name</title>
</head>

<body>
<form>
<table border = 1>
<tr>
  <td>name</td>
  <td><input type = "text"
             name = "userName" />
  </td>
</tr>

<tr>
  <td colspan = "2">
    <input type = "submit">
  </td>
</tr>
</table>
</form>


</body>
</html>    
    """

def respondToForm():
    userName = form["userName"].value
    print header
    print "<h1>Hi there, %s!</h1>" % userName

def main():
    if "userName" not in form.keys():
        createForm()
    else:
        respondToForm()

if __name__ == "__main__":
    main()


