import MySQLdb

Con = MySQLdb.Connect(host = "localhost",
                      port = 3306,
                      user = "aharris",
                      passwd = "password",
                      db = "aharris_db")

Cursor = Con.cursor()

SQL = "SELECT * FROM hero"
Cursor.execute(SQL)

results = Cursor.fetchall()
for record in results:

    for field in record:
        print "%s \t" % field,

    print
Con.close()
