#!/usr/bin/python

""" CGI_DB
    combine database concepts and CGI
    expects sqlite database called dvd.db in same
    directory. Uses CGI and apsw modules
"""

import sqlite3, cgi

connection = sqlite3.connect("dvd.db")
cursor = connection.cursor()

result = cursor.execute("SELECT * FROM vidRating")

print "Content-Type: text/html\n\n"
print """ 
<!DOCTYPE html PUBLIC
"-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang = "EN" xml:lang = "EN" dir = "ltr">

<head>
<meta http-equiv="content-type" content="text/xml; charset=iso-8859-1" />

<title>Database Results</title>
</head>

<body>
<h1>Videos in my collection</h1>

<table border = 1>
    <tr>
      <th>Name</th>
      <th>Rating</th>
    </tr>
"""

for (name, rating) in result:
    print """
    <tr>
      <td>%s</td>
      <td>%s</td>
    </tr>
    """ % (name, rating)

print """
</table>
</body>
</html>
"""
