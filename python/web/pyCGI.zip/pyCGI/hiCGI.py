#!/usr/bin/python

print "Content-type: text/html \n\n"

print "<h1>Hello, world!</h1>"

print "<ul>"
for i in range(11):
    print "  <li>%d</li>" % i

print "</ul>"


