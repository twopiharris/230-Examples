#!/usr/bin/python

print "Content-Type: text-html\n\n"

print "<ul>"
for i in range(1, 21):
    print "  <li>%d</li>" %i

print "</ul>"

