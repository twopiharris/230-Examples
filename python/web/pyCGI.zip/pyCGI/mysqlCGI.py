#!/usr/bin/python

print "Content-type: text/html \n\n"

import MySQLdb

Con = MySQLdb.Connect(host = "localhost",
                      port = 3306,
                      user = "aharris",
                      passwd = "passwd",
                      db = "aharris_db")

Cursor = Con.cursor()

SQL = "SELECT * FROM hero"
Cursor.execute(SQL)

print """

<table border = "1">
  <tr>
    <th>id</th>
    <th>name</th>
    <th>power</th>
    <th>weapon</th>
    <th>transportation</th>
  </tr>
"""

results = Cursor.fetchall()
for record in results:
    print "  <tr>"
    for field in record:
        print "    <td>%s</td>" % field,

    print "  </tr>"

print "</table>"
Con.close()
