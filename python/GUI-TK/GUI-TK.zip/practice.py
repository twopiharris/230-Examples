""" practice.py

"""

for i in range(10):
    print i